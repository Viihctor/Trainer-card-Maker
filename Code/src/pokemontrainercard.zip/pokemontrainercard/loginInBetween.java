/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pokemontrainercard;

/**
 *
 * @author 920415
 */
public class loginInBetween {
    private static String LoginId;

    public static String getLoginId() {
        return LoginId;
    }

    public static void setLoginId(String value) {
        LoginId = value;
    }
}
